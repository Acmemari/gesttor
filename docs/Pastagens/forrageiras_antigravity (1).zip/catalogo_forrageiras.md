# Catálogo de Espécies Forrageiras (Pastagens) do Brasil

Compilação de espécies forrageiras tropicais e de clima temperado utilizadas no Brasil, com nome comum, nome científico, gênero, alturas de manejo por método de pastejo (contínuo, rotacionado e rotatínuo), imagem real, características e histórico.

> **Nota sobre o método Rotatínuo:** a lotação rotatínua (*rotatinuous stocking*) foi desenvolvida pelo Prof. Paulo César de Faccio Carvalho (UFRGS, 2013). Baseia-se em entrar na altura ótima de pré-pastejo e sair com redução de aproximadamente 40% dessa altura. Para as espécies sem estudo publicado específico, o campo aparece como **"Não disponível"**.

> **Fontes de alturas:** Régua de Manejo de Pastagens (Embrapa Gado de Corte, 2017); Coleção SENAR/CNA nº 157 — Manejo de pastagens tropicais; literatura científica (UFRGS, ESALQ, Embrapa).


---

## 1. Capim-Marandu (Braquiarão)

![Capim-Marandu (Braquiarão)](imagens/marandu.jpg)

- **Nome científico:** *Brachiaria brizantha cv. Marandu (syn. Urochloa brizantha)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 35 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 30 a 40 cm (entrada) a 20 a 25 cm (saída) |
| Pastejo rotatínuo | 30 cm (entrada) a 18 cm (saída - resíduo de 40%) |

**Características:** O capim-Marandu é a forrageira mais cultivada no Brasil. Destaca-se pela boa produção de forragem, facilidade de manejo e resistência à cigarrinha-das-pastagens (Deois flavopicta). Exige solos de média a alta fertilidade e boa drenagem, não tolerando encharcamento. Tem hábito de crescimento cespitoso (touceira).

**Histórico:** Lançado pela Embrapa Gado de Corte em 1984, originário de sementes coletadas no Zimbábue (África) em 1967. Revolucionou a pecuária brasileira ao substituir a B. decumbens, que era suscetível à cigarrinha, tornando-se a base das pastagens no Cerrado e outras regiões.


---

## 2. Capim-Mombaça

![Capim-Mombaça](imagens/mombaca.jpg)

- **Nome científico:** *Panicum maximum cv. Mombaça (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado (exige manejo cuidadoso para evitar rapagem) |
| Pastejo rotacionado | 85 a 90 cm (entrada) a 40 a 50 cm (saída) |
| Pastejo rotatínuo | 90 cm (entrada) a 54 cm (saída - resíduo de 40%) |

**Características:** Gramínea de porte alto, formando grandes touceiras. Apresenta altíssimo potencial de produção de matéria seca e excelente qualidade nutricional. Exige solos de alta fertilidade e bom nível de adubação para expressar seu potencial. O manejo deve ser rigoroso para evitar o alongamento excessivo de colmos.

**Histórico:** Lançado em 1993 pela Embrapa Gado de Corte, proveniente de germoplasma coletado na Tanzânia em 1969. Foi uma das principais cultivares responsáveis pela intensificação da pecuária a pasto no Brasil, especialmente em sistemas rotacionados para gado de corte e leite.


---

## 3. Capim-Tanzânia

![Capim-Tanzânia](imagens/tanzania.jpg)

- **Nome científico:** *Panicum maximum cv. Tanzânia (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 70 cm (entrada) a 30 a 40 cm (saída) |
| Pastejo rotatínuo | 70 cm (entrada) a 42 cm (saída - resíduo de 40%) |

**Características:** Apresenta porte médio a alto, com folhas mais finas que o Mombaça e maior proporção de folhas na massa total. Tem alta qualidade forrageira e boa aceitabilidade pelos animais. Exige solos de média a alta fertilidade. É suscetível ao fungo Bipolaris maydis em algumas regiões.

**Histórico:** Lançado em 1990 pela Embrapa, também originário da Tanzânia. Foi a primeira grande alternativa ao capim-colonião comum, oferecendo maior produtividade de folhas e facilidade de manejo devido ao seu porte um pouco menor que o Mombaça.


---

## 4. Capim-Xaraés (MG-5 / Toledo)

![Capim-Xaraés (MG-5 / Toledo)](imagens/xaraes.jpg)

- **Nome científico:** *Brachiaria brizantha cv. Xaraés (syn. Urochloa brizantha)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 40 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 60 cm (entrada) a 30 a 40 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea de crescimento cespitoso, com folhas largas e compridas. Apresenta rápido rebrote e maior produção de forragem no final do período chuvoso em comparação ao Marandu. Exige solos de média a alta fertilidade e bom manejo para evitar o excesso de talos.

**Histórico:** Lançado em 2003 pela Embrapa (e comercializado também como MG-5 Vitória ou Toledo por outras empresas). Originário de Burundi (África), foi selecionado por sua alta produtividade e melhor distribuição estacional de forragem, sendo uma alternativa para diversificação.


---

## 5. Capim-Piatã

![Capim-Piatã](imagens/piata.jpg)

- **Nome científico:** *Brachiaria brizantha cv. BRS Piatã (syn. Urochloa brizantha)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 40 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 30 a 40 cm (entrada) a 20 a 25 cm (saída) |
| Pastejo rotatínuo | 30 cm (entrada) a 18 cm (saída - resíduo de 40%) |

**Características:** Planta de porte médio, com colmos finos e alta proporção de folhas, resultando em excelente valor nutritivo. Apresenta boa resistência às cigarrinhas típicas e melhor tolerância a solos com drenagem imperfeita que o Marandu. É muito utilizado em sistemas de Integração Lavoura-Pecuária (ILP).

**Histórico:** Lançado pela Embrapa em 2007, o BRS Piatã foi desenvolvido para suprir a necessidade de uma forrageira com alta qualidade nutricional, boa adaptação a diferentes solos e facilidade de dessecação para o plantio direto na palhada.


---

## 6. Braquiarinha (Brachiaria decumbens)

![Braquiarinha (Brachiaria decumbens)](imagens/decumbens.jpg)

- **Nome científico:** *Brachiaria decumbens cv. Basilisk (syn. Urochloa decumbens)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 30 cm (máxima) a 15 cm (mínima) |
| Pastejo rotacionado | 30 a 40 cm (entrada) a 15 a 20 cm (saída) |
| Pastejo rotatínuo | 25 cm (entrada) a 15 cm (saída - resíduo de 40%) |

**Características:** Hábito de crescimento decumbente (estolonífero), formando um gramado denso que protege bem o solo contra erosão. Muito rústica, tolera solos ácidos e de baixa fertilidade. Contudo, é altamente suscetível à cigarrinha-das-pastagens e pode causar fotossensibilização em ovinos e bezerros.

**Histórico:** Introduzida no Brasil na década de 1960 a partir de material australiano (cv. Basilisk, de origem ugandense). Foi a grande responsável pela abertura das áreas de Cerrado para a pecuária, devido à sua rusticidade e agressividade.


---

## 7. Capim-Zuri

![Capim-Zuri](imagens/zuri.jpg)

- **Nome científico:** *Panicum maximum cv. BRS Zuri (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 80 cm (entrada) a 40 cm (saída) |
| Pastejo rotatínuo | 80 cm (entrada) a 48 cm (saída - resíduo de 40%) |

**Características:** Gramínea de porte alto, semelhante ao Mombaça, mas com maior resistência ao fungo Bipolaris maydis e maior proporção de folhas. Altamente produtiva e de excelente valor nutritivo, exige solos férteis e bom manejo para controle do dossel.

**Histórico:** Lançado pela Embrapa em 2014 como uma evolução genética para áreas onde o Tanzânia e o Mombaça apresentavam problemas fitossanitários, garantindo maior segurança e produtividade em sistemas intensivos.


---

## 8. Capim-Massai

![Capim-Massai](imagens/massai.jpg)

- **Nome científico:** *Panicum maximum x P. infestus cv. Massai*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 50 a 55 cm (entrada) a 25 a 30 cm (saída) |
| Pastejo rotatínuo | 50 cm (entrada) a 30 cm (saída - resíduo de 40%) |

**Características:** Híbrido de porte baixo a médio, formando touceiras densas com folhas finas. É extremamente rústico, tolerando solos de menor fertilidade em comparação a outros panicuns, e tem boa tolerância à seca. É muito utilizado para ovinos e equinos.

**Histórico:** Lançado em 2001 pela Embrapa, foi selecionado no CIAT (Colômbia). Destacou-se no Brasil por ser um 'Panicum com rusticidade de Brachiaria', adaptando-se bem a regiões mais secas como o Nordeste e áreas de transição.


---

## 9. Capim-Elefante (Cameroon / Napier)

![Capim-Elefante (Cameroon / Napier)](imagens/elefante.jpg)

- **Nome científico:** *Pennisetum purpureum (syn. Cenchrus purpureus)*
- **Gênero:** Pennisetum / Cenchrus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 90 a 100 cm (entrada) a 40 a 50 cm (saída) |
| Pastejo rotatínuo | 100 cm (entrada) a 60 cm (saída - resíduo de 40%) |

**Características:** Gramínea perene de porte muito alto (podendo passar de 3 metros se não manejada). Tem altíssimo potencial de produção de biomassa, sendo tradicionalmente usada para corte (capineira) e silagem, mas cultivares modernas e anãs são excelentes para pastejo rotacionado intensivo. Exige alta fertilidade.

**Histórico:** Originário da África Tropical, foi introduzido no Brasil no início do século XX. O cv. Napier chegou em 1920 e o Cameroon em 1934. É a base da alimentação volumosa na bacia leiteira tradicional brasileira.


---

## 10. Tifton 85

![Tifton 85](imagens/tifton85.jpg)

- **Nome científico:** *Cynodon spp. (híbrido)*
- **Gênero:** Cynodon

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 20 cm (máxima) a 10 cm (mínima) |
| Pastejo rotacionado | 25 a 30 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | 25 cm (entrada) a 15 cm (saída - resíduo de 40%) |

**Características:** Gramínea estolonífera e rizomatosa de alto valor nutritivo e excelente digestibilidade. Responde muito bem à adubação nitrogenada e irrigação. Seu plantio é feito exclusivamente por mudas (estolões). Muito usada para fenação e pastejo de vacas leiteiras de alta produção e equinos.

**Histórico:** Desenvolvido pelo Dr. Glenn Burton na Universidade da Geórgia (EUA) e lançado em 1992, é um cruzamento entre Tifton 68 e uma introdução da África do Sul. Rapidamente se tornou o padrão ouro para feno e pastagens irrigadas no Brasil.


---

## 11. Azevém

![Azevém](imagens/azevem.jpg)

- **Nome científico:** *Lolium multiflorum*
- **Gênero:** Lolium

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado (manejo leniente) |
| Pastejo rotacionado | 20 a 25 cm (entrada) a 8 a 10 cm (saída) |
| Pastejo rotatínuo | 18 cm (entrada) a 11 cm (saída - resíduo de 40%) |

**Características:** Gramínea anual de inverno, de clima temperado. Possui altíssimo valor nutritivo (alta proteína e digestibilidade). Ressemeia-se naturalmente se bem manejada. Exige solos férteis e boa umidade. Base da pecuária de inverno no Sul do Brasil.

**Histórico:** Originário da bacia do Mediterrâneo, foi introduzido no Sul do Brasil por imigrantes europeus. O azevém é o modelo clássico onde o método Rotatínuo (Carvalho, 2013) foi extensamente testado e validado.


---

## 12. Aveia Preta

![Aveia Preta](imagens/aveiapreta.jpg)

- **Nome científico:** *Avena strigosa*
- **Gênero:** Avena

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 30 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | 25 cm (entrada) a 15 cm (saída - resíduo de 40%) |

**Características:** Gramínea anual de inverno, muito rústica e de rápido estabelecimento. Fornece forragem de excelente qualidade em períodos de escassez (outono/inverno). Muito consorciada com azevém e usada como planta de cobertura no plantio direto.

**Histórico:** Introduzida no Brasil no século XX, tornou-se fundamental no sistema produtivo do Sul e Sudeste, tanto para pastejo direto quanto para cobertura de solo, antecedendo a cultura da soja.


---

## 13. Amendoim Forrageiro

![Amendoim Forrageiro](imagens/amendoim.jpg)

- **Nome científico:** *Arachis pintoi*
- **Gênero:** Arachis

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Manejo leniente (manter boa cobertura) |
| Pastejo rotacionado | 15 a 20 cm (entrada) a 10 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa perene, estolonífera, de crescimento rasteiro. Fixa nitrogênio no solo e oferece forragem rica em proteína. É muito persistente sob pastejo e consorcia bem com gramíneas agressivas como braquiárias e Cynodon. Produz belas flores amarelas.

**Histórico:** Nativo do Brasil (vales dos rios São Francisco e Jequitinhonha), foi coletado em 1954 pelo botânico Geraldo Pinto. Cultivares como Belmonte, Amarillo e BRS Mandobi popularizaram seu uso na recuperação de pastagens e conservação de solo.


---

## 14. Estilosantes Campo Grande

![Estilosantes Campo Grande](imagens/estilosantes.jpg)

- **Nome científico:** *Stylosanthes capitata x Stylosanthes macrocephala*
- **Gênero:** Stylosanthes

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Manejo ajustado pela gramínea consorciada |
| Pastejo rotacionado | Manejo ajustado pela gramínea consorciada |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa tropical composta por uma mistura de duas espécies. Rústica, adapta-se bem a solos arenosos e de baixa fertilidade do Cerrado. Tem excelente capacidade de fixação de nitrogênio e ressemeadura natural. Consorcia muito bem com Brachiaria decumbens e Marandu.

**Histórico:** Desenvolvido pela Embrapa Gado de Corte e lançado em 2000. Foi um marco na pecuária nacional por ser a primeira leguminosa tropical realmente viável e persistente em larga escala comercial para consórcio em pastagens no Brasil Central.


---

## 15. Grama-Batatais (Pensacola)

![Grama-Batatais (Pensacola)](imagens/batatais.jpg)

- **Nome científico:** *Paspalum notatum*
- **Gênero:** Paspalum

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 10 a 15 cm (máxima) a 5 cm (mínima) |
| Pastejo rotacionado | 15 a 20 cm (entrada) a 5 a 8 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea perene, rizomatosa, de crescimento rasteiro e denso. Extremamente rústica, tolera solos pobres, secas e pisoteio intenso. Valor nutritivo moderado a baixo. Protege o solo contra erosão de forma excepcional.

**Histórico:** Espécie nativa das Américas (abundante no Brasil, especialmente no Sul e Sudeste). A cultivar Pensacola foi selecionada na Flórida (EUA) a partir de material sul-americano e reintroduzida. É a base das pastagens naturais em muitas regiões.


---

## 16. Capim-Paiaguás

![Capim-Paiaguás](imagens/paiaguas.jpg)

- **Nome científico:** *Brachiaria brizantha cv. BRS Paiaguás (syn. Urochloa brizantha)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 35 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 30 a 40 cm (entrada) a 20 a 25 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Cultivar de porte médio com colmos finos e alta produção de forragem na seca. Apresenta bom valor nutritivo, elevada produção de sementes e boa adaptação a sistemas de Integração Lavoura-Pecuária-Floresta (ILPF). Tolera bem o período seco mantendo folhas verdes.

**Histórico:** Lançado pela Embrapa em 2013, foi selecionado para complementar o Marandu e o Piatã, destacando-se pela produção de forragem durante a entressafra (estação seca) e pela facilidade de dessecação para plantio direto.


---

## 17. Capim-Ipyporã

![Capim-Ipyporã](imagens/ipypora.jpg)

- **Nome científico:** *Brachiaria ruziziensis x B. brizantha cv. BRS Ipyporã*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 35 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 30 a 40 cm (entrada) a 20 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Híbrido de braquiária com resistência às principais cigarrinhas-das-pastagens, alta qualidade de folhas e boa produção. Combina a rusticidade da B. brizantha com a qualidade da B. ruziziensis. Boa cobertura de solo e palatabilidade.

**Histórico:** Lançado pela Embrapa e Unipasto em 2017. O nome 'Ipyporã' significa 'aquele que cobre bem a terra' em tupi-guarani. Foi desenvolvido para ser uma alternativa resistente a pragas com elevado valor nutritivo.


---

## 18. Capim-Humidícola (Tupi)

![Capim-Humidícola (Tupi)](imagens/humidicola.jpg)

- **Nome científico:** *Brachiaria humidicola cv. Tupi (syn. Urochloa humidicola)*
- **Gênero:** Brachiaria / Urochloa

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 20 cm (máxima) a 10 cm (mínima) |
| Pastejo rotacionado | 20 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea estolonífera de crescimento prostrado, extremamente tolerante a solos encharcados, mal drenados e de baixa fertilidade. Forma excelente cobertura de solo. Valor nutritivo relativamente baixo, mas alta resistência ao pisoteio e à seca.

**Histórico:** Originária da África Oriental, foi amplamente difundida em áreas úmidas da Amazônia e do Pantanal. A cultivar Tupi foi lançada pela Embrapa com maior produtividade que a humidícola comum.


---

## 19. Capim-Quênia

![Capim-Quênia](imagens/quenia.jpg)

- **Nome científico:** *Panicum maximum cv. BRS Quênia (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 65 cm (entrada) a 35 cm (saída) |
| Pastejo rotatínuo | 65 cm (entrada) a 39 cm (saída - resíduo de 40%) |

**Características:** Gramínea de porte médio-alto com estabelecimento rápido e vigoroso. Folhas largas e macias, com alto valor nutritivo. Apresenta boa produção de forragem e bom perfilhamento, sendo de manejo um pouco mais fácil que o Mombaça.

**Histórico:** Lançado pela Embrapa em 2017, foi desenvolvido para oferecer rápido estabelecimento e alta produtividade, sendo indicado para sistemas intensivos de produção de carne e leite.


---

## 20. Capim-Tamani

![Capim-Tamani](imagens/tamani.jpg)

- **Nome científico:** *Panicum maximum cv. BRS Tamani (híbrido)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 50 cm (entrada) a 25 cm (saída) |
| Pastejo rotatínuo | 50 cm (entrada) a 30 cm (saída - resíduo de 40%) |

**Características:** Primeiro híbrido de Panicum maximum do Brasil. Porte baixo, folhas finas e abundantes, com excelente relação folha/colmo e alto valor nutritivo. Facilita o manejo do pastejo por ser mais baixo, permitindo melhor controle do dossel.

**Histórico:** Lançado pela Embrapa em 2015, foi o primeiro cultivar híbrido (apomítico) de Panicum desenvolvido no país, marcando avanço no melhoramento genético de forrageiras tropicais voltado à facilidade de manejo.


---

## 21. Capim-Aruana

![Capim-Aruana](imagens/aruana.jpg)

- **Nome científico:** *Panicum maximum cv. Aruana (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 40 a 60 cm (entrada) a 25 a 30 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea de porte baixo a médio, com excelente perfilhamento e rebrota rápida. Muito utilizada para ovinos devido ao seu porte e alta produção de folhas. Boa tolerância ao pastejo frequente e intenso.

**Histórico:** Lançado pelo Instituto de Zootecnia (IZ-SP) em 1989. Foi um dos primeiros panicuns de porte baixo voltados para a ovinocultura e bovinocultura de leite em sistemas rotacionados.


---

## 22. Capim-Colonião

![Capim-Colonião](imagens/coloniao.jpg)

- **Nome científico:** *Panicum maximum cv. Colonião (syn. Megathyrsus maximus)*
- **Gênero:** Panicum / Megathyrsus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 90 cm (entrada) a 40 a 50 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea de porte muito alto (pode passar de 2 metros), formando grandes touceiras. Alta produção de forragem em solos férteis, mas com manejo difícil e rápida perda de qualidade. Hoje frequentemente considerado planta invasora em áreas degradadas.

**Histórico:** Foi a primeira planta da espécie P. maximum a chegar ao Brasil, trazida da África provavelmente junto com o tráfico de escravizados (usado como cama nos navios). Dominou as pastagens brasileiras por décadas antes do advento das braquiárias.


---

## 23. Capim-Andropogon

![Capim-Andropogon](imagens/andropogon.jpg)

- **Nome científico:** *Andropogon gayanus cv. Planaltina / Baetí*
- **Gênero:** Andropogon

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 25 a 30 cm (máxima) a 20 cm (mínima) |
| Pastejo rotacionado | 40 a 50 cm (entrada) a 25 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea cespitosa muito rústica, extremamente tolerante a solos ácidos, com alto teor de alumínio e baixa fertilidade. Apresenta boa tolerância à seca e resistência à cigarrinha. Forragem de valor nutritivo moderado.

**Histórico:** Originário da África, a cultivar Planaltina foi lançada pela Embrapa Cerrados em 1980. Foi importante na ocupação de solos arenosos e ácidos do Cerrado onde outras forrageiras não se estabeleciam bem.


---

## 24. Coastcross

![Coastcross](imagens/coastcross.jpg)

- **Nome científico:** *Cynodon dactylon (híbrido)*
- **Gênero:** Cynodon

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 15 a 20 cm (máxima) a 10 cm (mínima) |
| Pastejo rotacionado | 20 a 30 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea estolonífera de alta digestibilidade e bom valor nutritivo. Muito usada para fenação de qualidade e pastejo de animais de alta exigência. Responde bem à adubação e irrigação. Plantio por mudas (estolões).

**Histórico:** Desenvolvido por Glenn Burton na Geórgia (EUA) e lançado em 1967, é um híbrido entre Coastal Bermudagrass e uma introdução do Quênia. Foi muito difundido no Brasil para produção de feno de alta qualidade.


---

## 25. Grama-Estrela

![Grama-Estrela](imagens/estrela.jpg)

- **Nome científico:** *Cynodon nlemfuensis*
- **Gênero:** Cynodon

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 15 a 20 cm (máxima) a 10 cm (mínima) |
| Pastejo rotacionado | 20 a 30 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea estolonífera de crescimento agressivo, formando touceiras com estolões em forma de estrela. Boa produção e qualidade, rústica e resistente à seca. Muito usada em pastagens de bovinos de leite e corte.

**Histórico:** Originária da África Oriental, foi introduzida no Brasil e difundida em diversas regiões. Antecede os híbridos Tifton e Coastcross, sendo a base do gênero Cynodon nas pastagens tropicais.


---

## 26. Milheto

![Milheto](imagens/milheto.jpg)

- **Nome científico:** *Pennisetum glaucum (syn. Cenchrus americanus)*
- **Gênero:** Pennisetum / Cenchrus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 50 a 60 cm (entrada) a 20 a 30 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea anual de verão, de rápido crescimento e alta produção de forragem de qualidade. Tolerante à seca e a solos arenosos. Usado para pastejo, silagem, cobertura de solo (plantio direto) e produção de grãos.

**Histórico:** Originário da África (região do Sahel), é uma das culturas anuais mais antigas. No Brasil, popularizou-se como planta de cobertura no plantio direto e como forragem de transição entre safras no Centro-Oeste e Sul.


---

## 27. Sorgo Forrageiro

![Sorgo Forrageiro](imagens/sorgo.jpg)

- **Nome científico:** *Sorghum bicolor*
- **Gênero:** Sorghum

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | 60 a 100 cm (entrada) a 30 a 40 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea anual de verão, de porte alto e alta produção de biomassa. Muito tolerante à seca. Usado principalmente para silagem, mas também para pastejo (cultivares específicas). Atenção ao ácido cianídrico em plantas jovens ou estressadas.

**Histórico:** Originário da África, foi domesticado há milhares de anos. No Brasil é amplamente cultivado para silagem como alternativa ao milho em regiões com restrição hídrica, sendo importante na pecuária leiteira e de corte.


---

## 28. Hemártria

![Hemártria](imagens/hemartria.jpg)

- **Nome científico:** *Hemarthria altissima*
- **Gênero:** Hemarthria

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 15 a 25 cm (máxima) a 10 cm (mínima) |
| Pastejo rotacionado | 25 a 30 cm (entrada) a 10 a 15 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Gramínea perene estolonífera, tolerante a solos úmidos e a baixas temperaturas. Boa palatabilidade e cobertura de solo. Adaptada às regiões mais frias do Sul do Brasil, com bom desempenho em várzeas.

**Histórico:** Originária da África, foi introduzida no Sul do Brasil e estudada por instituições como a Epagri e Embrapa Clima Temperado como opção perene para áreas úmidas e de clima subtropical.


---

## 29. Leucena

![Leucena](imagens/leucena.jpg)

- **Nome científico:** *Leucaena leucocephala*
- **Gênero:** Leucaena

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Ramoneio (consumo de ramos e folhas pelos animais) |
| Pastejo rotacionado | Rebaixamento periódico a 50 a 80 cm |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa arbustiva/arbórea de alto teor proteico, usada em sistemas de pastejo direto (banco de proteína) e silvipastoris. Fixa nitrogênio e tolera bem a seca. Contém mimosina, que exige atenção no manejo para evitar toxidez.

**Histórico:** Originária da América Central (México), foi introduzida amplamente nos trópicos. No Brasil é usada em consórcio com gramíneas e em sistemas integrados, especialmente no semiárido nordestino e em sistemas silvipastoris.


---

## 30. Guandu (Feijão-guandu)

![Guandu (Feijão-guandu)](imagens/guandu.jpg)

- **Nome científico:** *Cajanus cajan*
- **Gênero:** Cajanus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Ramoneio / banco de proteína |
| Pastejo rotacionado | Rebaixamento a 40 a 60 cm |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa arbustiva de ciclo anual a semiperene, com alto teor de proteína. Muito rústica, tolera seca e solos pobres. Usada como banco de proteína, adubação verde e recuperação de solos degradados.

**Histórico:** Originário da Índia/África, é cultivado há milênios. No Brasil, popularizou-se como banco de proteína para a pecuária e como planta recuperadora de solos, com cultivares como o Guandu Anão e o BRS Mandarim.


---

## 31. Calopogônio

![Calopogônio](imagens/calopogonio.jpg)

- **Nome científico:** *Calopogonium mucunoides*
- **Gênero:** Calopogonium

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Manejo ajustado pela gramínea consorciada |
| Pastejo rotacionado | Manejo ajustado pela gramínea consorciada |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa volúvel/trepadeira de crescimento rápido, usada principalmente como cobertura de solo e em consórcios. Fixa nitrogênio e protege o solo, mas tem palatabilidade moderada (os animais a consomem menos quando há gramínea).

**Histórico:** Originária da América Tropical, foi muito utilizada em consórcios em pastagens tropicais e como adubação verde em culturas perenes (cacau, seringueira) na fase de formação.


---

## 32. Trevo-Branco

![Trevo-Branco](imagens/trevobranco.jpg)

- **Nome científico:** *Trifolium repens*
- **Gênero:** Trifolium

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | 10 a 15 cm (máxima) a 5 cm (mínima) |
| Pastejo rotacionado | 15 a 20 cm (entrada) a 5 a 8 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa perene de clima temperado, estolonífera e rasteira. Tolera umidade e pastejo intenso, mantendo-se por ressemeadura natural. Alto valor nutritivo. Consorcia bem com azevém e gramíneas de inverno no Sul.

**Histórico:** Originário da Europa e Ásia, foi introduzido no Sul do Brasil por imigrantes. É uma das principais leguminosas das pastagens cultivadas de inverno na região subtropical brasileira.


---

## 33. Trevo-Vermelho

![Trevo-Vermelho](imagens/trevovermelho.jpg)

- **Nome científico:** *Trifolium pratense*
- **Gênero:** Trifolium

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado (manejo leniente) |
| Pastejo rotacionado | 20 a 25 cm (entrada) a 8 a 10 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa de clima temperado, de ciclo bienal a perene curto, com hábito ereto e touceira. Alto valor nutritivo e boa produção de forragem. Mais sensível ao pastejo intenso que o trevo-branco, preferindo manejo rotacionado.

**Histórico:** Originário da Europa, foi introduzido no Sul do Brasil. É utilizado em consórcio com gramíneas de inverno e para produção de feno, contribuindo com fixação de nitrogênio e qualidade da dieta.


---

## 34. Cornichão

![Cornichão](imagens/cornichao.jpg)

- **Nome científico:** *Lotus corniculatus*
- **Gênero:** Lotus

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado (manejo leniente) |
| Pastejo rotacionado | 20 a 25 cm (entrada) a 8 a 10 cm (saída) |
| Pastejo rotatínuo | Não disponível |

**Características:** Leguminosa perene de clima temperado, com taninos condensados que reduzem o risco de timpanismo (empanzinamento) e melhoram o aproveitamento da proteína. Tolera solos ácidos e mal drenados. Flores amarelas características.

**Histórico:** Originário da Europa, foi introduzido no Sul do Brasil e tornou-se importante leguminosa perene de inverno, com cultivares como São Gabriel e Nilo difundidas no Rio Grande do Sul.


---

## 35. Alfafa

![Alfafa](imagens/alfafa.jpg)

- **Nome científico:** *Medicago sativa*
- **Gênero:** Medicago

| Método de pastejo | Altura de manejo |
|---|---|
| Pastejo contínuo | Não recomendado |
| Pastejo rotacionado | Corte/pastejo no início do florescimento (~35 a 45 cm) a 5 a 10 cm |
| Pastejo rotatínuo | Não disponível |

**Características:** Considerada a 'rainha das forrageiras', é uma leguminosa perene de altíssimo valor nutritivo e produtividade. Exige solos férteis, bem drenados e corrigidos (pH adequado). Usada principalmente para feno e pastejo de animais de alta produção.

**Histórico:** Originária da Ásia Central (Pérsia), é uma das forrageiras mais antigas cultivadas pela humanidade. No Brasil é cultivada principalmente no Sul e Sudeste para alimentação de gado leiteiro de alta produção e equinos.


---
