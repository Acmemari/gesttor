# Pacote de Importação — Espécies Forrageiras do Brasil

Este pacote contém os dados de **35 espécies/cultivares forrageiras** utilizadas no Brasil, prontos para importação no Antigravity.

## Conteúdo
- `forrageiras.json` — Dados estruturados (recomendado para importação em banco/app).
- `forrageiras.csv` — Mesmos dados em planilha (UTF-8, separador vírgula).
- `catalogo_forrageiras.md` — Catálogo legível com imagens, para conferência humana.
- `imagens/` — Imagens reais de cada planta (o nome do arquivo está no campo `imagem` de cada registro).

## Campos de cada registro
- `nome` — Nome comum/popular
- `nome_cientifico` — Nome científico (com sinonímia quando aplicável)
- `genero` — Gênero botânico
- `alturas_manejo.pastejo_continuo` — Altura de manejo em lotação contínua (cm)
- `alturas_manejo.pastejo_rotacionado` — Altura de entrada/saída em lotação rotacionada (cm)
- `alturas_manejo.pastejo_rotatinuo` — Altura no método rotatínuo (Carvalho, 2013) ou "Não disponível"
- `imagem` — Nome do arquivo de imagem na pasta `imagens/`
- `caracteristicas` — Texto sobre as principais características
- `historico` — Texto sobre o histórico/origem

## Observação sobre o Rotatínuo
A lotação rotatínua foi desenvolvida pelo Prof. Paulo César de Faccio Carvalho (UFRGS).
A regra geral aplicada: entrada na altura ótima de pré-pastejo, saída com redução de ~40%.
Espécies sem referência publicada específica trazem "Não disponível" neste campo.
